<?php

session_start();
$conn = mysqli_connect("localhost","root","","contact_app");
if(!$conn){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}
if ($_SESSION['user_email']){
    $email=$_SESSION['user_email'];
    $query="SELECT * FROM contacts where user_email='$email'";
    $result=mysqli_query($conn,$query) or die(mysqli_error($conn));
    }
    else{
        header('Location:signin.php');
    }

if (isset($_POST['submit']))
{

$name=$_POST['name'];
$num=$_POST['number'];
$email=$_POST['email_id'];
$user_em=$_SESSION['user_email'];
$sql = "INSERT INTO contacts (name, phone, email, user_email) VALUES ('$name', '$num', '$email', '$user_em');";
if(mysqli_query($conn, $sql))
{  
    $message = "Contact Saved Successfully";
    
}
else
{  
    $message = "Could not insert record";
    
    
}
	echo "<script type='text/javascript'>alert('$message');</script>";
    $query="SELECT * FROM contacts where user_email='$user_em'";
    $result=mysqli_query($conn,$query) or die(mysqli_error($conn));
}




?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    
    <style>
        .login{
            margin-top:5px;
            text-align: center;

        }
        input{
        width: 15%;
        padding: 8px 16px;
        margin: 8px 0;
        border-radius:7px;
        box-sizing: border-box;
        border: 3px solid #ccc;
        -webkit-transition: 0.5s;
        transition: 0.5s;
        outline: none;
        }
        h2{
            margin-left:160px;
        }
        label{
            margin:15px;
        }

        input:focus {
        border: 3px solid #555;
        }

        .button input{
            width:7%;
            color:white;
            margin-left:194px;
            background-color:#1976D2;
        }

        .button input:hover{
            cursor: pointer;
            border:3px solid transparent;
        }

        tr:hover{
            opacity: 1;
        }
        table 
        {
            width: 100%;
            margin-bottom: 1%;
            border: 1px solid black;
          
            
        }
        th, td
        {
            border: 1px solid black;
           height:65px;
            color: black;
        }
        th
        {
            background-color:grey;
            color: white;
        }
        td
        {
            text-align: center;
        }
        
        tbody tr:nth-of-type(even)
        {
            background-color:rgb(177, 176, 177);
            color: black;
            opacity: 0.8;

        }
        tbody tr:nth-of-type(odd)
        {
            background-color: rgb(255, 252,247);
            color: black;
            opacity: 0.8;
        }
        tbody tr:hover
        {
            color: #212529;
            background-color:hsl(300, 22%, 96%) ;
            visibility: 10%;
            opacity: 1;
        }
        
        
        .content{
            
            margin-left:420px;
            color:#fff;
            width: 50%;
           
           
          
        }
        h3{
            text-align:center;
        }
        .log{
            
            text-decoration:none;
            width:7%;
            padding:5px;
            color:white;
            padding: 8px 16px;
            
            border-radius:7px;
            box-sizing: border-box;
            border: 3px solid #ccc;
            -webkit-transition: 0.5s;
            transition: 0.5s;
            outline: none;
            float:right;
            background-color:#1976D2;
            font-size:12px;
            
        }
        .log:hover{
            cursor: pointer;
            border:3px solid transparent;
        }
      
        
    </style>
</head>
<body>
    <div class="login">

        <h2>Contact Form and Contact List Page <a href="logout.php" class="log">Logout</a></h2><br>
        <h3>Add Contacts</h3> <br>


        <form id="signin" method="post" name="form">
            <label  for="name">Name</label>
            <input type="text" id="name" name="name" class="name" required><br><br>
            <label for="password">Ph No</label>
            <input type="number" id="number" name="number" class="number" required><br><br>
            <label  for="email">Email</label>
            <input type="email" id="email_id" name="email_id" class="email_id" required><br><br>
            <div class="button">
            <input type="Submit" value="Save"  name="submit" id="submit" class="submit">
            </div>
            

        </form>
        
    </div>
    <h3>My Contacts</h3>
    <div class="content">
  
    <table class="cal">
    
      <thead>
        <tr>
			
			<th>Name</th>
			<th>Ph No</th>
			<th>Email</th>
			
        </tr>
	  </thead>
	  <tbody>
    <?php
        while($rows=mysqli_fetch_assoc($result))
        {
    ?>
		<tr>
			
			<td><?php echo $rows['name']; ?></td>
			<td><?php echo $rows['phone']; ?></td>
			<td><?php echo $rows['email']; ?></td>
			
		</tr>
    <?php
        }
    ?>	
	  </tbody>
    </table>
    </div>


</body>
</html>


