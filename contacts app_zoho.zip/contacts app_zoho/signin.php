<?php
session_start();
if (isset($_POST['submit']))
{
    $conn = mysqli_connect("localhost","root","","contact_app");
if(!$conn){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}

$email=$_POST['email_id'];
$pass=$_POST['password'];

$sql = "SELECT * FROM signup WHERE email = '$email' AND password = '$pass' ;";
$sql_result = mysqli_query ($conn, $sql) or die ('request "Could not execute SQL query" '.$sql);

        $user = mysqli_fetch_assoc($sql_result);
		if(!empty($user)){
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_password'] = $user['password'];
            $message='Logged in successfully';
            header('Location:form.php');
        }
		else{
			$message = 'Wrong email or password.';
		}
	echo "<script type='text/javascript'>alert('$message');</script>";

    
}

?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    
    <style>
        .login{
            margin-top:5px;
            text-align: center;

        }
        input{
        width: 20%;
        padding: 10px 20px;
        margin: 8px 0;
        border-radius:7px;
        box-sizing: border-box;
        border: 3px solid #ccc;
        -webkit-transition: 0.5s;
        transition: 0.5s;
        outline: none;
        }

        input:focus {
        border: 3px solid #555;
        }

        .button input{
            color:white;
            background-color:#1976D2;
        }

        .button input:hover{
            cursor: pointer;
            border:3px solid transparent;
        }
    </style>
</head>
<body>
    <div class="login">

        <h2>Sign In</h2><br>

        <p>Don't have an account?<a href="http://localhost/contacts%20app_zoho/singup.php">Sign Up</a></p> <br>


        <form id="signin" method="post" name="signin">
            <label  for="email">Email</label><br>
            <input type="email" id="email_id" name="email_id" class="email_id" required><br><br>
            <label for="password">Password</label><br>
            <input type="password" id="password" name="password" class="password" required><br><br>
            
            <div class="button">
            <input type="Submit" value="Sign In"  name="submit" id="submit" class="submit">
            </div>
        </form>
        
    </div>
</body>
</html>