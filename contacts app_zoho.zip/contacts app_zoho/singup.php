<?php
session_start();
$conn = mysqli_connect("localhost","root","","contact_app");
if(!$conn){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}
if (isset($_POST['submit']))
{
$email=$_POST['email_id'];
$pass=$_POST['password'];
$sec=$_POST['secret'];
$sql = "INSERT INTO signup (email, password, secret) VALUES ('$email', '$pass', '$sec');";
if(mysqli_query($conn, $sql))
{  
    $message = "Successfully Resigesterd";
    header('Location:signin.php');
}
else
{  
    $message = "email already exists";
    
    
}
	echo "<script type='text/javascript'>alert('$message');</script>";
}


?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <style>
        .register{
            margin-top:5px;
            text-align: center;

        }
        input{
        width: 20%;
        padding: 10px 20px;
        margin: 8px 0;
        border-radius:7px;
        box-sizing: border-box;
        border: 3px solid #ccc;
        -webkit-transition: 0.5s;
        transition: 0.5s;
        outline: none;
        }

        input:focus {
        border: 3px solid #555;
        }

        .button input{
            color:white;
            background-color:#1976D2;
        }

        .button input:hover{
            cursor: pointer;
            border:3px solid transparent;
        }
        .terms{
            font-size: 12px;
            color: grey;
            
        }
    </style>
</head>
<body>
    <div class="register">
        <h2>Sign Up</h2><br>

        <p>Already have an account?<a href="http://localhost/contacts%20app_zoho/signin.php">Sign In</a></p> <br>


        <form id="signup" method="post" name="signup">
            <label  for="email">Email</label><br>
            <input type="email" id="email_id" name="email_id" class="email_id" required><br><br>
            <label for="password">Password</label><br>
            <input type="password" id="password" name="password" class="password" required><br><br>
            <label for="password">Secret</label><br>
            <input type="password" id="secret" name="secret" class="secret" required><br><br>
            <div class="button">
            <input type="Submit" value="Sign Up"  name="submit" id="submit" class="submit">
            </div>
            <p class="terms"> By clicking the "Sign Up" button you are creating an <br>
                account and you agree to the Terms of Use.</p>
        </form>
        
    </div>
</body>
</html>